# RAIDER — Premium Screen Recorder
**DEVELOPED BY LEONARDO**

Este é um projeto-base Android em Kotlin, organizado para abrir/compilar via Gradle e GitHub Actions.

## Importante sobre o estado desta entrega
O projeto contém a estrutura Android, tela inicial, solicitação oficial de autorização MediaProjection, serviço-base de captura e painel flutuante. **A codificação do vídeo, gravação de áudio, captura de imagem e galeria ainda precisam ser implementadas e testadas antes de considerar o aplicativo completo.** O serviço de gravação não gera MP4 nesta versão. Não anuncie esta versão como gravador funcional completo.

## Compilação
Consulte o arquivo PDF `TUTORIAL-GITHUB-RAIDER.pdf` entregue separadamente.

## Requisitos
- Android 8.0+ (minSdk 26)
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- SDK de compilação 35

## Permissões e privacidade
A sobreposição exige autorização explícita do usuário. A captura de tela usa o diálogo oficial MediaProjection. Nenhuma gravação deve ser iniciada sem autorização visível.
