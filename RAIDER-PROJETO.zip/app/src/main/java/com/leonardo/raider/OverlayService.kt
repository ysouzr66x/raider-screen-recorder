package com.leonardo.raider

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(10, 8, 10, 8)
            background = GradientDrawable().apply {
                setColor(Color.WHITE); cornerRadius = 100f
                setStroke(2, Color.rgb(22,139,255))
            }
        }
        fun control(symbol: String, color: Int, action: () -> Unit): TextView {
            return TextView(this).apply {
                text = symbol; textSize = 22f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply { setColor(color); shape = GradientDrawable.OVAL }
                val p = (resources.displayMetrics.density * 48).toInt()
                val lp = LinearLayout.LayoutParams(p, p).apply { marginStart = 5; marginEnd = 5 }
                root.addView(this, lp)
                setOnClickListener { action() }
            }
        }
        control("●", Color.RED) {
            startActivity(Intent(this, RecordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        control("♫", Color.rgb(205,0,20)) {
            Toast.makeText(this, "O áudio é configurado antes de iniciar a gravação.", Toast.LENGTH_SHORT).show()
        }
        control("▣", Color.rgb(75,175,25)) {
            Toast.makeText(this, "Para capturar a tela, utilize a opção de captura na tela principal.", Toast.LENGTH_SHORT).show()
        }
        control("⚙", Color.DKGRAY) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        control("×", Color.rgb(235,55,20)) { stopSelf() }

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 100 }
        root.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; return false }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (e.rawX-downX).toInt()
                        params.y = startY + (e.rawY-downY).toInt()
                        try { windowManager?.updateViewLayout(root, params) } catch (_: Exception) {}
                        return true
                    }
                }
                return false
            }
        })
        panel = root
        try { windowManager?.addView(root, params) } catch (_: Exception) { panel = null; stopSelf() }
    }

    override fun onDestroy() {
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        panel = null
        super.onDestroy()
    }
}
