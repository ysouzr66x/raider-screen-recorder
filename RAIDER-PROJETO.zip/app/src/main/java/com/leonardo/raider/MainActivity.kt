package com.leonardo.raider

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val overlayRequest = 201
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 9, 13)
        window.navigationBarColor = Color.rgb(8, 9, 13)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 34, 24, 24)
            setBackgroundColor(Color.rgb(8, 9, 13))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                setPadding(0, 10, 0, 10)
            }

        root.addView(text("RAIDER", 34f, Color.rgb(22,139,255)))
        root.addView(text("PREMIUM SCREEN RECORDER", 13f, Color.LTGRAY))
        root.addView(text("Grave a tela, capture imagens e controle tudo pelo painel flutuante.", 16f))
        status = text("", 14f, Color.rgb(0,217,255))
        root.addView(status)

        val overlay = Button(this).apply { text = "ATIVAR PAINEL FLUTUANTE" }
        val start = Button(this).apply { text = "ABRIR GRAVADOR" }
        val settings = Button(this).apply { text = "CONFIGURAÇÕES" }
        root.addView(overlay); root.addView(start); root.addView(settings)
        root.addView(text("DEVELOPED BY LEONARDO", 12f, Color.GRAY))
        setContentView(root)

        fun refresh() {
            status.text = if (Settings.canDrawOverlays(this)) "● Sobreposição autorizada" else "● Sobreposição ainda não autorizada"
        }
        refresh()
        overlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Painel RAIDER ativado", Toast.LENGTH_SHORT).show()
            }
        }
        start.setOnClickListener { startActivity(Intent(this, RecordActivity::class.java)) }
        settings.setOnClickListener {
            val options = arrayOf("Qualidade: padrão", "Microfone: solicitar ao gravar", "Sobre o RAIDER")
            android.app.AlertDialog.Builder(this).setTitle("Configurações")
                .setItems(options) { _, which ->
                    val msg = when(which) {
                        0 -> "A gravação usa uma configuração compatível com o dispositivo."
                        1 -> "A permissão de microfone será solicitada quando necessária."
                        else -> "RAIDER — Developed by Leonardo"
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }.show()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest && Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) status.text =
            if (Settings.canDrawOverlays(this)) "● Sobreposição autorizada" else "● Sobreposição ainda não autorizada"
    }
}
