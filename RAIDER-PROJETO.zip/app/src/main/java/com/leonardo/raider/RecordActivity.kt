package com.leonardo.raider

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import android.view.Gravity
import android.graphics.Color

class RecordActivity : Activity() {
    private val captureRequest = 410
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(8,9,13))
        }
        root.addView(TextView(this).apply {
            text = "AUTORIZAR GRAVAÇÃO"
            textSize = 24f; setTextColor(Color.rgb(22,139,255))
        })
        root.addView(TextView(this).apply {
            text = "O Android exibirá uma confirmação do sistema antes de compartilhar a tela com o RAIDER. A gravação só começa depois da sua autorização."
            textSize = 16f; setTextColor(Color.WHITE); setPadding(0,20,0,20)
        })
        val record = Button(this).apply { text = "INICIAR GRAVAÇÃO" }
        root.addView(record)
        record.setOnClickListener {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
        }
        setContentView(root)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, RecordingService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "Autorização recebida. Preparando gravação.", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
