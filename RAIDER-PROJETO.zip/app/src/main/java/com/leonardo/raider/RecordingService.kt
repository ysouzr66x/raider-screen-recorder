package com.leonardo.raider

import android.app.*
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.widget.Toast

/*
 * Base segura do serviço de captura. A autorização MediaProjection é recebida
 * pelo diálogo oficial do Android. A implementação de codificação/salvamento
 * de vídeo precisa ser completada e testada por dispositivo antes de uso final.
 */
class RecordingService : Service() {
    private var projection: MediaProjection? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = Notification.Builder(this, "raider_recording")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("RAIDER")
            .setContentText("Sessão de captura autorizada")
            .setOngoing(true)
            .build()
        startForeground(41, notification)
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("resultData", Intent::class.java)
                   else @Suppress("DEPRECATION") intent?.getParcelableExtra("resultData")
        if (resultCode == Activity.RESULT_OK && data != null) {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            Toast.makeText(this, "Sessão autorizada. Codificador de vídeo ainda precisa ser integrado.", Toast.LENGTH_LONG).show()
        } else stopSelf()
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("raider_recording", "RAIDER gravação", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        projection?.stop()
        projection = null
        super.onDestroy()
    }
}
